-------------------------------------------------------------------------------
-- Apellidos, Nombre: 
-- Titulacion, Grupo: 
--
-- Estructuras de Datos. Grados en Informatica. UMA.
-------------------------------------------------------------------------------

module AVLBiDictionary( BiDictionary
                      , empty
                      , isEmpty
                      , size
                      , insert
                      , valueOf
                      , keyOf
                      , deleteByKey
                      , deleteByValue
                      , toBiDictionary
                      , compose
                      , isPermutation
                      , orbitOf
                      , cyclesOf
                      ) where

import qualified DataStructures.Dictionary.AVLDictionary as D
import qualified DataStructures.Set.BSTSet               as S

import           Data.List                               (intercalate, nub,
                                                          (\\))
import           Data.Maybe                              (fromJust, fromMaybe,
                                                          isJust)
import           Test.QuickCheck


data BiDictionary a b = Bi (D.Dictionary a b) (D.Dictionary b a)

-- | Exercise a. empty, isEmpty, size

empty :: (Ord a, Ord b) => BiDictionary a b
empty = Bi D.empty D.empty

isEmpty :: (Ord a, Ord b) => BiDictionary a b -> Bool
isEmpty (Bi dk dv) = D.isEmpty dk && D.isEmpty dv

size :: (Ord a, Ord b) => BiDictionary a b -> Int
size (Bi dk dv) = D.size dk

-- | Exercise b. insert

insert :: (Ord a, Ord b) => a -> b -> BiDictionary a b -> BiDictionary a b
insert clave valor(Bi dk dv)
  | D.isDefinedAt clave dk = insert clave valor (Bi (D.delete clave dk) (D.delete(fromJust(D.valueOf clave dk)) dv))
  | D.isDefinedAt valor dv = insert clave valor (Bi (D.delete (fromJust(D.valueOf valor dv)) dk)  (D.delete valor dv))
  | otherwise = (Bi (D.insert clave valor dk)(D.insert valor clave dv)) 

-- | Exercise c. valueOf

valueOf :: (Ord a, Ord b) => a -> BiDictionary a b -> Maybe b
valueOf k (Bi dk dv) = D.valueOf k dk

-- | Exercise d. keyOf

keyOf :: (Ord a, Ord b) => b -> BiDictionary a b -> Maybe a
keyOf v (Bi dk dv) = D.valueOf v dv

-- | Exercise e. deleteByKey

deleteByKey :: (Ord a, Ord b) => a -> BiDictionary a b -> BiDictionary a b
deleteByKey k b@(Bi dk dv)
  | D.isDefinedAt k dk = Bi (D.delete k dk) (D.delete (fromJust(D.valueOf k dk)) dv)
  | otherwise = b

-- | Exercise f. deleteByValue

deleteByValue :: (Ord a, Ord b) => b -> BiDictionary a b -> BiDictionary a b
deleteByValue k b@(Bi dk dv)
  | D.isDefinedAt k dv = Bi (D.delete (fromJust(D.valueOf k dv)) dk) (D.delete k dv)
  | otherwise = b

-- | Exercise g. toBiDictionary

{-
toBiDictionary :: (Ord a, Ord b) => D.Dictionary a b -> BiDictionary a b
toBiDictionary dk = Bi dk (aBidic (D.keysValues dk)  D.empty)
 where 
  aBidic [] dv = (dv)
  aBidic (x:xs) dv = aBidic xs (D.insert (snd x)(fst x) dv)
-}

toBiDictionary :: (Ord a, Ord b) => D.Dictionary a b -> BiDictionary a b
toBiDictionary dic = dic2biDic (D.keys dic) (D.values dic)
  where 
    dic2biDic [] [] = empty
    dic2biDic [] _ = error "Inyectivo"
    dic2biDic _ [] = error "Inyectivo"
    dic2biDic (k:ks) (v:vs) = insert k v (dic2biDic ks vs)

-- | Exercise h. compose

{-
compose :: (Ord a, Ord b, Ord c) => BiDictionary a b -> BiDictionary b c -> BiDictionary a c
compose (Bi dk1 dv1) (Bi dk2 dv2) = buscarYa単adir (Bi dk1 dv1) (Bi dk2 dv2)(encontrarComunes (D.values dk1) (D.keys dk2) []) D.empty D.empty
   where 
     buscarYa単adir (Bi dk1 dv1) (Bi dk2 dv2) [] dk dv = Bi dk dv
     buscarYa単adir (Bi dk1 dv1) (Bi dk2 dv2) (x:xs) dk dv = buscarYa単adir  (Bi dk1 dv1) (Bi dk2 dv2) (xs) (D.insert (fromJust(D.valueOf x dv1)) (fromJust(D.valueOf x dk2)) dk) (D.insert (fromJust(D.valueOf x dk2))(fromJust(D.valueOf x dv1))  dv)
     encontrarComunes [] claves2 comunes = comunes
     encontrarComunes (x:xs) claves2 comunes 
       |elem x claves2 = encontrarComunes xs claves2 (x:comunes)
       |otherwise = encontrarComunes xs claves2 comunes
-}

compose :: (Ord a, Ord b, Ord c) => BiDictionary a b -> BiDictionary b c -> BiDictionary a c
compose (Bi dk dv) (Bi dk' dv') = toBiDictionary (linkD dv dk')
  where
    linkD v k
      | D.isEmpty v && D.isEmpty k = D.empty
      | otherwise = insert' (D.values v) (D.values k)
        where 
          insert' [] [] = D.empty
          insert' (x:xs) (y:ys) = D.insert x y (insert' xs ys) 

-- | Exercise i. isPermutation

isPermutation :: Ord a => BiDictionary a a -> Bool
isPermutation = undefined



-- |------------------------------------------------------------------------


-- | Exercise j. orbitOf

orbitOf :: Ord a => a -> BiDictionary a a -> [a]
orbitOf = undefined

-- | Exercise k. cyclesOf

cyclesOf :: Ord a => BiDictionary a a -> [[a]]
cyclesOf = undefined

-- |------------------------------------------------------------------------


instance (Show a, Show b) => Show (BiDictionary a b) where
  show (Bi dk dv)  = "BiDictionary(" ++ intercalate "," (aux (D.keysValues dk)) ++ ")"
                        ++ "(" ++ intercalate "," (aux (D.keysValues dv)) ++ ")"
   where
    aux kvs  = map (\(k,v) -> show k ++ "->" ++ show v) kvs
