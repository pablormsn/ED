-------------------------------------------------------------------------------
-- Ford-Fulkerson Algorithm. Maximal flow for a weighted directed graph.
--
-- Student's name:
-- Student's group:
--
-- Data Structures. Grado en Informática. UMA.
-------------------------------------------------------------------------------

module DataStructures.Graph.FordFulkerson where

import Data.List  ((\\))
import DataStructures.Graph.WeightedDiGraph
import DataStructures.Graph.WeightedDiGraphBFT

{-
Inicialmente se crea una lista de arcos vacía para representar la solución.
Mientras haya un camino (path) de S a T en G:
    Se calcula el flujo máximo (mf) de dicho camino (path).
    Para cada arco del grafo G que forme parte del camino (path), se decrementa su peso en mf unidades.
    Para cada arco del grafo G que forme parte del camino contrario a path, se incrementa su peso en mf unidades.
    A la lista solución se le añade el flujo de los arcos del camino (path) pero con peso mf.
La lista solución contendrá los arcos que forman el grafo con flujo máximo.
La suma de los pesos de los arcos de la solución que salen de S será el flujo máximo de la red.
-}

maxFlowPath :: Path (WDiEdge a Integer) -> Integer
maxFlowPath p = minimum (map getWeight p)

getWeight :: WDiEdge a Integer -> Integer
getWeight (E x w y) = w

getX :: WDiEdge a Integer -> a
getX (E x w y) = x

getY :: WDiEdge a Integer -> a
getY (E x w y) = y

updateEdge ::(Eq a) => a -> a -> Integer -> [WDiEdge a Integer] -> [WDiEdge a Integer]
updateEdge x y p [] = [E x p y]
updateEdge x y p edges
    | getX (head edges) == x && getY (head edges) == y = (updateWeight (head edges)) ++ (tail edges)
    | otherwise = (head edges):updateEdge x y p (tail edges)
        where
            updateWeight (E x w y) = if (w+p) > 0 then [(E x (w+p) y)] else []

updateEdges :: (Eq a) => Path (WDiEdge a Integer) -> Integer -> [WDiEdge a Integer] -> [WDiEdge a Integer]
updateEdges pth p [] = pth
updateEdges [] p xs = xs
updateEdges (y:ys) p xs =  updateEdges ys p (updateEdge (getX y) (getY y) p xs)

addFlow :: (Eq a) => a -> a -> Integer -> [WDiEdge a Integer] -> [WDiEdge a Integer]
addFlow x y p [] = [E x p y]
addFlow x y p (sol:resSol)
    | (x,y) == (getY sol, getX sol) && getWeight sol < p = (E x (p-getWeight sol) y):resSol
    | (x,y) == (getY sol, getX sol) && getWeight sol > p = (E x (getWeight sol-p) y):resSol
    | (x,y) == (getY sol, getX sol) && getWeight sol == p = resSol
    | (x,y) == (getX sol, getY sol) = (updateWeight sol) ++ resSol
    | otherwise = sol:(addFlow x y p resSol)
        where
            updateWeight (E x w y) = if (w+p) > 0 then [(E x (w+p) y)] else []

addFlows :: (Eq a) => Path (WDiEdge a Integer) -> Integer -> [WDiEdge a Integer] -> [WDiEdge a Integer]
addFlows [] p sol = sol
addFlows pth p [] = pth
addFlows (x:xs) p sol = addFlows xs p (addFlow (getX x) (getY x) p sol)

fordFulkerson :: (Ord a) => (WeightedDiGraph a Integer) -> a -> a -> [WDiEdge a Integer]
fordFulkerson g src dst = aux g src dst [] (bftPathTo g src dst)
    where
        aux _ _ _ sol Nothing = sol
        aux wdg src dst sol (Just path) =  aux newWdg src dst (addFlows path mf sol) (bftPathTo newWdg src dst)
            where
                mf = maxFlowPath path
                reverseEdges = reversePath path
                edges = (updateEdges reverseEdges mf (updateEdges path (-mf) (weightedDiEdges wdg)))
                newWdg = mkWeightedDiGraphEdges (vertices wdg) edges

reversePath :: Path (WDiEdge a Integer) -> Path (WDiEdge a Integer)
reversePath [] = []
reversePath (e : es) = reversePath es ++ [reverseEdge e]

reverseEdge :: WDiEdge a Integer -> WDiEdge a Integer
reverseEdge (E x w y) = E y w x

maxFlow :: (Ord a) => [WDiEdge a Integer] -> a -> Integer
maxFlow sol src = sumarPesos (filter (\(E x _ _) -> x == src) sol)
    where 
        sumarPesos [] = 0
        sumarPesos (x:xs) = getWeight x + sumarPesos xs

maxFlowMinCut :: (Ord a) => (WeightedDiGraph a Integer) -> a -> a -> [a] -> Integer
maxFlowMinCut = undefined



-- A partir de aquí hasta el final
-- SOLO para alumnos a tiempo parcial 
-- sin evaluación continua

localEquilibrium :: (Ord a) => WeightedDiGraph a Integer -> a -> a -> Bool
localEquilibrium = undefined

sourcesAndSinks :: (Eq a) => WeightedDiGraph a b -> ([a],[a])
sourcesAndSinks = undefined

unifySourceAndSink :: (Eq a) => WeightedDiGraph a Integer -> a -> a -> WeightedDiGraph a Integer
unifySourceAndSink = undefined
