module MyModule (
     PQueue
    , empty
    , isEmpty
    , first
    , dequeue
    , enqueue
    ) where

data PQueue a = Empty | Node a (PQueue a) deriving Show

empty :: PQueue a
empty = Empty

isEmpty :: PQueue a -> Bool
isEmpty Empty = True
isEmpty _     = False

first :: Ord p => PQueue p -> p
first Empty = error "Empty"
first (Node x pq) = minpq x pq
    where 
        minpq x Empty  = x
        minpq x  (Node y queue) 
            | x < y = minpq x  queue
            | otherwise = minpq y queue

enqueue :: Ord a => a -> PQueue a -> PQueue a
enqueue x pq = (Node x pq)

dequeue Empty = error "Empty"
dequeue (Node x pq) = deleteMin x pq
    where 
        deleteMin x Empty = Empty
        deleteMin x (Node y queue)
            | x < y = Node y (deleteMin x queue)
            | otherwise = Node x (deleteMin y queue)
