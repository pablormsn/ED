module MaxiphobicHeap (
      MaxiphobicHeap
    , minElem
    , delMin
    , insert
    , empty
    , size
)where 

data MaxiphobicHeap a = Empty | Node a  Int (MaxiphobicHeap a) (MaxiphobicHeap a) deriving Show

empty = Empty

minElem Empty = error "Empty heap"
minElem (Node x _ _ _) = x

delMin Empty = error "Empty heap"
delMin (Node _ _ a b) = merge a b

size Empty = 0
size (Node _ w _ _) = w

insert x a = merge a (singleton x)

singleton x = Node x 1 Empty Empty


merge :: (Ord a) => MaxiphobicHeap a -> MaxiphobicHeap a -> MaxiphobicHeap a
merge h1 Empty = h1
merge Empty h2 = h2
merge h1@(Node a x ai ad) h2@(Node b y bi bd) 
  | a < b = combine a ai ad h2
  | otherwise = combine b h1 bi bd
    where 
        combine elem a b c = Node elem (size a + size b + size c + 1) (primero) (merge segundo tercero)
            where (primero , segundo , tercero) = sort3 a b c
            
sort3 x y z 
 | size x < size y = sort3 y x z
 | size x < size z = sort3 z y x
 | otherwise = (x , y , z)



{-
merge a Empty = a
merge Empty b = b
merge a@(Node x al ar) b@(Node y bl br)
    | x < y = Node x al (merge ar b)
    | otherwise = Node y bl (merge br a)
-}