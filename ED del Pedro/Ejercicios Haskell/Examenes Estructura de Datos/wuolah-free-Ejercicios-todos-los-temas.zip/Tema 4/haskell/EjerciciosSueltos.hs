import DataStructures.SearchTree.AVL

levels :: AVL a -> [a]
levels x = foldInOrder (:) [] x

data Tree a = Empty | Node a [Tree a] deriving Show

leavesT :: Tree a -> [a]
leavesT Empty = []
leavesT (Node x []) = [x]
leavesT (Node x xs) = (concat [leavesT lista | lista <-xs])

atLevelT :: Tree a -> Int -> [a]
atLevelT Empty _ = []
atLevelT (Node v xs) n 
    | n == 0 = [v]
    | otherwise = concat [atLevelT t (n-1) | t <- xs]

