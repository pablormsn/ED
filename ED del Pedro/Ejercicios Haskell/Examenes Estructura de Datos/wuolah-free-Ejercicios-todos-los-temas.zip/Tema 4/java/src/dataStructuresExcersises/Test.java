package dataStructuresExcersises;

import dataStructures.searchTree.BST;

import java.util.Random;

public class Test {
    public static void main(String[] args) {
        MaxiphobicHeapExcersise<Integer> temp = new MaxiphobicHeapExcersise<>();
        temp.insert(1);
        temp.insert(2);
        temp.insert(10);
        temp.insert(4);
        System.out.println(temp);
        temp.delMin();
        System.out.println(temp);
    }
}
