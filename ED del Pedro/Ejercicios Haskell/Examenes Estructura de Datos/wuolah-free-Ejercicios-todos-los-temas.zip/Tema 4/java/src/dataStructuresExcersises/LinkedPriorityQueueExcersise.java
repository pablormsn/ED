package dataStructuresExcersises;
import dataStructures.priorityQueue.EmptyPriorityQueueException;
import dataStructures.priorityQueue.LinkedPriorityQueue;
import dataStructures.priorityQueue.PriorityQueue;

import java.util.StringJoiner;

public class LinkedPriorityQueueExcersise<T extends Comparable<? super T>> implements PriorityQueue<T>{
    private class Node<T> {
        public T elem;
        public Node <T> next;
        private Node(){
            elem = null;
            next = null;
        }
        private Node(T elem, Node<T> next) {
            this.elem = elem;
            this.next = next;
        }
    }

    private Node <T> root;
    private int size;

    public LinkedPriorityQueueExcersise(){
        root = null;
        size = 0;
    }

    @Override
    public boolean isEmpty() {
        return size==0;
    }

    @Override
    public T first() {
        if (size == 0) throw new EmptyPriorityQueueException();
        return root.elem;
    }

    @Override
    public void dequeue() {
        if (size == 0) throw new EmptyPriorityQueueException();
        root = root.next;
        size--;
    }


    @Override
    public void enqueue(T x) {
        if (size == 0){
            root = new Node<>(x , null);
        } else if (x.compareTo(root.elem)<0) {
            Node<T> node = new Node<>(x, root);
            root = node;
        } else  {
            //int count = 0;
            Node<T> pointer = root;
            boolean saved = false;
            while (!saved){
                if (pointer.next == null){
                    pointer.next = new Node<>(x,null);
                    saved = true;
                } else if (x.compareTo(pointer.next.elem)<0) {
                    Node<T> node = new Node<>(x,pointer.next);
                    pointer.next = node;
                    saved = true;
                } else {
                    pointer = pointer.next;
                    //count++;
                }
            }
        }
        size++;
    }

    @Override
    public String toString() {
        StringJoiner st = new StringJoiner(" , ", "[", "]");
        Node<T> temp = root;
        for (int i = 0 ; i<size ; i++){
            st.add(temp.elem.toString());
            temp = temp.next;
        }
        return st.toString();
    }
}
