package dataStructuresExcersises;

import dataStructures.priorityQueue.EmptyPriorityQueueException;
import dataStructures.priorityQueue.PriorityQueue;

import java.util.StringJoiner;

public class NonSortedLinkedPriorityQueueExercise <T extends Comparable<? super T>> implements PriorityQueue<T> {
    private class Node<T> {
        public T elem;
        public Node <T> next;
        public Node(){
            elem = null;
            next = null;
        }
        public Node(T elem, Node<T> next) {
            this.elem = elem;
            this.next = next;
        }
        public void update(Node<T> node) {
            elem = node.elem;
            next = node.next;
        }
    }
    private Node<T> root;
    private int size = 0;
    @Override
    public boolean isEmpty() {
        return size == 0;
    }

    @Override
    public void enqueue(T x) {
        root = new Node<>(x , root);
        size++;
    }

    @Override
    public T first() {
        if (isEmpty()) throw new EmptyPriorityQueueException();
        T campeon = root.elem;
        Node<T> pointer = root.next;
        while (pointer!=null){
            if (campeon.compareTo(pointer.elem)>0) campeon = pointer.elem;
            pointer = pointer.next;
        }
        return campeon;
    }

    @Override
    public void dequeue() {
        if (isEmpty()) throw new EmptyPriorityQueueException();
        else if (size == 1) {
            root = null;
        } else {
            Node<T> min = root;
            Node<T> next = root;
            while (next != null) {
                if (min.elem.compareTo(next.elem)>0) min = next;
                next = next.next;
            }
            // Modificamos los valores del objeto en vez de crear uno nuevo
            if(min.next != null){
                min.update(min.next);
            }
        }
        size--;
    }
     @Override
    public String toString() {
        StringJoiner st = new StringJoiner(" , ", "[", "]");
        Node<T> temp = root;
        for (int i = 0 ; i<size ; i++){
            st.add(temp.elem.toString());
            temp = temp.next;
        }
        return st.toString();
    }
}
