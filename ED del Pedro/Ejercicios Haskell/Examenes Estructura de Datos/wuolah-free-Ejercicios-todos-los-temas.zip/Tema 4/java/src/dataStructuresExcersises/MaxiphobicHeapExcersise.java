package dataStructuresExcersises;

import dataStructures.heap.EmptyHeapException;
import dataStructures.heap.Heap;

public class MaxiphobicHeapExcersise <T extends Comparable<? super T>> implements Heap<T> {
    public class Node<T> {

        public T elem;
        public Node<T> left;
        public Node<T> right;
        public int heapSize;

        public Node(){
            elem = null;
            left = null;
            right = null;
            heapSize = 0;
        }
        public Node(T elem , int heapSize) {
            this.elem = elem;
            this.heapSize = heapSize;
            left = null;
            right = null;
        }

        public Node(T elem, Node<T> left, Node<T> right, int heapSize) {
            this.elem = elem;
            this.left = left;
            this.right = right;
            this.heapSize = heapSize;
        }

        @Override
        public String toString() {
            return "(" + elem + " " + left.toString() + " " + right.toString();
        }
    }
    private Node<T> root;
    private int size;

    public MaxiphobicHeapExcersise() {
        this.root = null;
        size = 0;
    }

    @Override
    public boolean isEmpty() {
        return size == 0;
    }

    @Override
    public int size() {
        return size;
    }

    @Override
    public void insert(T x) {
        root = merge(singleton(x) , root);
        size++;
    }

    @Override
    public T minElem() {
        return root.elem;
    }

    @Override
    public void delMin() {
        if (isEmpty()) throw new EmptyHeapException();
        root = merge(root.left , root.right);
        size--;
    }
    private Node<T> singleton(T x) {
        return new Node<>(x , 1);
    }
    private Node<T> merge (Node<T> a , Node<T> b) {
        if (a == null) return b;
        if (b == null) return a;

        Node<T> newRoot;
        Node<T> _1;
        Node<T> _2;
        Node<T> _3;

        if (a.elem.compareTo(b.elem)<0) {
            newRoot = a;
            _1 = a.left;
            _2 = a.right;
            _3 = b;
        }else {
            newRoot = b;
            _1 = b.left;
            _2 = b.right;
            _3 = a;
        }

        Node<T> temp;
        if (_1.elem.compareTo(_2.elem)>0) {
            if (_1.elem.compareTo(_3.elem)>0) {
                // Nothing, already first
            } else {
                temp = _3;
                _3 = _1;
                _1 = temp;
            }
        } else {
            if (_2.elem.compareTo(_3.elem)>0) {
                temp = _2;
                _2 = _1;
            } else {
                temp = _3;
                _3 = _1;
            }
            _1 = temp;
        }

        return new Node<>(newRoot.elem , _1 , merge(_2,_3) , _1.heapSize + _2.heapSize + _3.heapSize);
    }

    @Override
    public String toString() {
        return root.toString();
    }
}
