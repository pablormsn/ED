package dataStructures.heap;

import java.util.Arrays;

/**
 * Array heap implementado por mi en clase del 9 dic
 */
public class ArrayHeap <T extends Comparable<? super T>> implements Heap<T>{
    private static final int ROOT_INDEX = 0;
    private int size;
    private T [] nodes;

    @SuppressWarnings("unchecked")
    public ArrayHeap (int n){
        size=0;
        nodes=(T[]) new Comparable[n];
    }
    public ArrayHeap(){
        this(10);
    }

    @Override
    public boolean isEmpty() {
        return size==0;
    }

    @Override
    public int size() {
        return size;
    }

    @Override
    public void insert(T x) {
        if (size==nodes.length) nodes = Arrays.copyOf(nodes,nodes.length*2);
        nodes[size] = x;
        heapUp();
        size++;
    }

    private void heapUp() {
        int i = size;
        while (!isRoot(i) && nodes[parent(i)].compareTo(nodes[i])>0){
            swap(parent(i),i);
        }
    }

    @Override
    public void delMin() {
        if (isEmpty()) throw new EmptyHeapException();
    }

    @Override
    public T minElem() {
        if (isEmpty()) throw new EmptyHeapException();
        return nodes[ROOT_INDEX];
    }

    private void swap(int i1,int i2){
        T temp = nodes[i1];
        nodes[i1] = nodes[i2];
        nodes[i2] = temp;
    }
    private int parent(int i) {
        return (i-1)/2;
    }
    private int leftChild(int i){
        return 2*i+1;
    }
    private int rightChild(int i){
        return 2*i+2;
    }
    private boolean isRoot(int i) {
        return i==ROOT_INDEX;
    }
}
