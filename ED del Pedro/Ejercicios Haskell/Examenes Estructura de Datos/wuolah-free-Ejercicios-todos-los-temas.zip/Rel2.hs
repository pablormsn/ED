
-------------------------------------------------------------------------------
-- Estructuras de Datos. 2o Curso. ETSI Informática. UMA --
-- (completa y sustituye los siguientes datos)
-- Titulación: Grado en Ingeniería .......................................... del Software

-- Fecha de entrega: 28 | Oct | 2020 --
-- Relación de Ejercicios 2. Ejercicios resueltos: ..........
-- ------------------------------------------------------------------------------- 

import Test.QuickCheck
import Data.List

--1 
data Direction = North | South | East | West
    deriving (Eq,Enum,Show)

{-
(<<) :: Direction -> Direction ->Bool
(<<) x y =  x<y
-}
(<<) :: Direction -> Direction ->Bool
(<<) x y = dir1 < dir2
    where dir1 = fromEnum x
          dir2 = fromEnum y

--p_menor x y = True ==> (x<y) == (x<<y)
instance Arbitrary Direction where
    arbitrary =do 
        n<-choose(0,3)
        return $ toEnum n

--2 
maximoYresto :: Ord a => [a] -> (a,[a])
maximoYresto []     = error "lista vacia"
maximoYresto (x:xs) = max x xs []
    where   max n [] ys = (n,ys)
            max n (x:xs) ys
                |n<x = max x xs (n:ys)
                |otherwise = max n xs (x:ys)

maximoYresto' :: Ord a => [a] -> (a,[a])
maximoYresto' []     = error "lista vacia"
maximoYresto' (x:[]) = (x,[])
maximoYresto' (x:xs) = (maximo , componenteDescartado:resto)
    where maximo               = x `max` siguiente
          (siguiente, resto)   = maximoYresto' xs
          componenteDescartado = if x==maximo then siguiente else x 

--3
reparte :: [a] ->([a],[a])
reparte []       = ([],[])
reparte (x:[])   = (x:[],[])
reparte (x:y:xs) = (x:izq,y:der)
    where (izq,der) =reparte xs

--4
distintos :: Eq a => [a] -> Bool
distintos []     = True 
distintos (x:xs) = not (elem x xs) && distintos xs 

--5
replicate' :: Int -> a -> [a]
replicate' n b = [b | _<-[1..n]]

p_replicate' n x = n>= 0 && n<=1000 ==> length (filter (==x) xs) ==n && length (filter (/=x) xs) == 0 
    where xs =replicate' n x

--6
divideA x y = y `mod` x==0
divisores n 
    | n==0      = error "no hay divisores del 0"
    | otherwise = [x | x<-[1..(abs n)] , x`divideA`n]

divisores' 0 = error "no hay divisores del 0"
divisores' n = map (*(-1)) (reverse divi) ++ divi
    where divi =[x | x<-[1..(abs n)] , x`divideA`n]

--7 
mcd x y = maximum [a | a<-divisores x ,elem a (divi)]
    where divi = divisores y

p_mcd x y z = x/=0 && y/=0 && z/=0 ==> mcd (x*z) (y*z) == (abs z)*(mcd x y)

--mcm x y = (x*y) `div`(mcd x y)

--8
esPrimo n = [n] == [x | x<-[2..n] , mod n x == 0]

primosHasta n = [x | x<-[1..n],esPrimo x]

primosHasta' n = filter (esPrimo) [1..n]

p1_primos x = True ==> primosHasta x == primosHasta' x

--9
pares :: Integer ->[(Integer,Integer)]
pares n = [(a,b) | a<-primosHasta (n `div`2), b <-primosHasta n, a+b==n]

goldbach n = n>2 && []/=pares n

goldbachHasta :: Integer -> Bool
goldbachHasta n = n>=4 && and [goldbach x | x<-[4,6..n]]

goldbachDébilHasta :: Integer -> Bool
goldbachDébilHasta n = n>5 && and [goldbachDébil x | x<-[7,9..n]]
    where goldbachDébil n = (even (n-3)) && (n-3>2)

--10
esPerfecto x = x == sum (take ((length divi)-1) (divi))
    where divi = divisores x

perfectosMenoresQue n = [x | x<-[1..n] , esPerfecto x]

--11
take' :: Int -> [a]->[a]
take' n xs=[x | (p,x)<- zip [1..n] xs]


drop' :: Int -> [a]->[a] 
drop' n xs=[x | (p,x)<- zip [0..] xs,p>=n]

p_takeDrop n xs = True ==> (take' n xs) ++ (drop' n xs) == xs

--12
concat' :: [[a]] -> [a]
concat' xs =foldr (++) [] xs

concat'' :: [[a]] -> [a]
concat'' xss = [ a | x <- xss, a <- (elemInterior x)]
    where elemInterior x = [a | a <- x]

--13
{-
    comprueba si la lista está ordenada
-}
desconocida :: Ord a => [a] -> Bool
desconocida xs = and [x<=y | (x,y) <- zip xs (tail xs)]

--14
{-
inserta :: Ord a => a -> [a]->[a]
inserta x xs = (takeWhile (<=x) xs) ++ [x] ++ (dropWhile (<=x) xs)
-}

inserta x [] = [x]
inserta n (x:xs) 
    | n<x = n:x:xs
    |otherwise = x:(inserta n xs)

p1_inserta x xs = desconocida xs ==> desconocida(inserta x xs)

{-
    Porque estamos insertando un elmento de forma ordenada. tras insertar
    todos los elementos conseguiremos la lista ordenada
-}

ordena xs =foldr (inserta) [] xs

p_ordena xs = True ==> desconocida (ordena xs)

--15
geométrica n k = lista
    where lista = n:[ a*k | a<-lista]


{-
    Para todo x y r mayor de 0, la division entre 
    los 100 primeros elementos de la lista geométrica
    de valor inicial x y ratio r, la division entre
    ese valor y el anterior da como resultado el ratio
-}

--múltiplosDe n = iterate (+n) 0

potenciasDe n = iterate (*n) 1

--16
múltiplosDe n
    | n>0 = iterate (+n) 0

primeroComún :: Ord a => [a] -> [a] -> a
primeroComún (x:xs) (y:ys)
    | x<y = if (elemOrd x (y:ys)) then x else (primeroComún xs (y:ys))
    |otherwise = if (elemOrd y (x:xs)) then y else (primeroComún (x:xs) ys)
        where 
            elemOrd _ [] = False
            elemOrd n (x:xs)
                |n>x       = elemOrd n xs
                |n==x      = True
                |otherwise = False

mcm x y = primeroComún (tail (múltiplosDe x)) (tail (múltiplosDe y))

--17
primeroComúnDeTres :: Ord a => [a] -> [a]->[a]->a
primeroComúnDeTres (x:xs) (y:ys) (z:zs)
    |x>y          = primeroComúnDeTres (x:xs) ys (z:zs) 
    |x>z          = primeroComúnDeTres (x:xs) (y:ys) zs
    |y>x || z>x   = primeroComúnDeTres xs (y:ys) (z:zs)
    |x==y && x==z = x

p_primeroComúnDeTres a xs ys zs = (elem a xs) && (elem a ys) && (elem a zs)==> primeroComúnDeTres xs ys zs <= a

--18
factPrimos :: Integer ->[Integer]
factPrimos x = fp x 2
    where fp x d
            |x' < d = [x]
            |r == 0 = d:(fp x' d)
            |otherwise = fp x (d+1)
            where (x',r) = divMod x d

{-
    a)
    empezamos el contador en el primer primo (2)
    mientras que el número sea mayor que el factor primo que estamos
    consultamos continuamos iterando buscamos primos más grandes
    que dividan el numero original
    Si el resto es 0 lo agrega
    Usamos como caso base el mismo número que entra en la
    división

    b)
    Porque solo elegimos aquellos valores cuyo resto es 0,
    Es absurdo que un un numero mayor que otro devuelva un resultado
    entero
-}

factPrimos' x = fp x 2
    where fp x d
            |x' < d = [x]
            |r == 0 = d:(fp x' d)
            |even d = (fp x (d+1))
            |otherwise = fp x (d+2)
                where (x',r) = divMod x d
p_factores x = True ==> x == product (factPrimos x)

--19
mezcla [] ys = ys
mezcla xs [] = xs
mezcla (x:xs) (y:ys) 
    | x>y = y:mezcla (x:xs) ys
    | x<y = x:mezcla xs (y:ys)
    | otherwise = x:mezcla xs ys

mcm' x y = product (mezcla (factPrimos x) (factPrimos y))

p_mcm' x y = x>=0 && y>=0 ==> mcm' x y == lcm x y


--20
mezc' [] _ = []
mezc' _ [] = []
mezc' (x:xs) (y:ys)
    | x>y = mezc' (x:xs) ys
    | x<y = mezc' xs (y:ys)
    |otherwise = x:mezc' xs ys

mcd'' x y=product (mezc' (factPrimos x) (factPrimos y))

p_mcd'' x y = x>0 && y>0 ==> mcd'' x y == gcd x y

--21
nub' :: Eq a => [a]->[a]
nub' [] = []
nub' (x:xs) = x: nub' (filter (/=x) xs)

p_nub' xs = True ==> nub xs == nub' xs

p_sinRepes xs = True ==> distintos (nub' xs)
--Porque podría ser una lista con elementos distintos 
--cualesquiera y no lo detectaría

todosEn :: Eq a => [a] -> [a] ->Bool
todosEn ys xs = all (`elem`xs) ys

p_sinRepes' xs = True ==> distintos (nub' xs) && ((nub' xs) `todosEn` xs)

--22
binarios 0 = [[]]
binarios n = map ('0':) (binarios (n-1)) ++ map ('1':) (binarios (n-1))

p_binarios n = n>=0 && n<=10 ==> long xss == 2^n && distintos xss && all (`todosEn` "01") xss
    where xss = binarios n

long :: [a] -> Integer
long xs = fromIntegral (length xs)

--23 
varRep n xs 
    | n == 0 = [[]]
    | n<0 = error "negativo"
    | otherwise = [ a:serie | a <-xs , serie <-(varRep (n-1) xs) ]

p_varRep m xs = m>=0 && m<=5 && distintos xs ==> long vss == n^m && distintos vss && all (`todosEn`xs) vss 
    where vss =varRep m xs 
          n = long xs


-- length (varRep 5 ".-" )  32 posibilidades

--24
var n xs 
    | n==0 = [[]]
    | n<0 = error "negativo"
    | otherwise = [ a:serie | a <-xs , serie <-(var (n-1) xs), a `notElem`serie]



p_var m xs = n<=5 && distintos xs && m>=0 && m<=n ==> long vss ==fact n `div` fact (n-m) && distintos vss && all distintos vss && all (`todosEn` xs) vss
    where
        vss = var m xs 
        n = long xs
        fact :: Integer ->Integer
        fact x = product [1..x]

--length (var 3 [1..9])   504 posibilidades

--25
intercala n [] = [[n]]
intercala a xs = [ (take contador xs) ++ [a] ++ (drop contador xs )| contador <-[0..(tam)]]
    where tam = length xs

perm [] = [[]]
--perm xs =  TODO

-- 26 TODO

-- 27 
esPrefijoDe [] _ = True
esPrefijoDe _ [] = False
esPrefijoDe (x:xs) (y:ys) = x==y && esPrefijoDe xs ys

p_Prefijo xs ys = True ==> esPrefijoDe xs ys == isPrefixOf xs ys

búsquedas :: String -> String -> [Int]
búsquedas xs ys = aux xs ys 0
    where 
        aux xs ys contador
            |ys == [] = []
            |esPrefijoDe xs ys = contador:(aux xs (drop (length xs) ys) (contador+(length xs)))
            |otherwise = aux xs (tail ys) (contador+1)


distancia xs [] = length xs
distancia [] ys = length ys
distancia (x:xs) (y:ys)
    |x==y = distancia xs ys
    |otherwise = 1 + distancia xs ys


parecidas tolerancia xs ys = [ x | x<- [0..(length ys - 1)] , 
    tolerancia>= distancia xs (take (length xs) (drop x ys))]

-- 28 TODO

--29
qsort []     = []
qsort (x:xs) = qsort small ++ mid ++ qsort large
    where
        small = [y | y<-xs, y<x]
        mid   = [y | y<-xs, y==x] ++ [x]
        large = [y | y<-xs, y>x]

mediana xs
    |odd tam = ord !! div tam 2
    |otherwise = mean (ord !! (div tam 2)) (ord !! ((div tam 2)-1))
        where 
            tam =length ord
            ord = qsort  xs
            mean x y = (x+y) / 2

p_mediana :: [Double] -> Property
p_mediana xs =True ==>  all (\ x -> x<= (mediana xs)) (take (div (length xs) 2) (qsort xs))

--30 TODO
fibs :: [Integer]
fibs = 0:1:fibsAux 0 1
    where fibsAux x y = (x+y):fibsAux y (x+y)


-- 35 

data Nat = Cero | Suc Nat deriving (Eq, Ord, Show) -- Clase con dos constructores

uno, dos, tres :: Nat
uno = Suc Cero
dos = Suc uno
tres = Suc dos

instance Arbitrary Nat where
    arbitrary = do
        n<- choose (0,25)
        return $aNat n

aNat:: Integer -> Nat
aNat 0 = Cero
aNat n | n>0 = Suc . aNat  $ n-1 

xor :: Bool -> Bool -> Bool
xor x y 
    |x==y = False
    |otherwise = True

esPar :: Nat -> Bool
esPar Cero = True
esPar (Suc n) = xor True (esPar n)

p_par :: Nat -> Property
p_par x = True ==> esPar x == esPar (Suc (Suc x))

instance Num Nat where -- Instancia de num nat (metodos de num en nat)
    Cero + y = y
    Suc x + y = Suc (x+y)
    abs x = x
    signum Cero = Cero
    signum x = uno
    fromInteger x = aNat x
    Cero * y = Cero
    Suc x * y = x*y + y 
    y - Cero = y
    Suc x - y 
        | Suc x < y = error "negativo"
        | Suc x == y = Cero
        | otherwise = Suc (x-y)


p_comutativa :: Nat -> Nat -> Property
p_comutativa x y =True ==> x + y == y + x

p_asociativa :: Nat -> Nat-> Nat -> Property
p_asociativa x y z = True ==>(x + y) + z == x + (y + z)

p_neutro :: Nat -> Property
p_neutro x = True ==> x + Cero == x


p_comutativaProducto :: Nat->Nat -> Property
p_comutativaProducto x y = True ==> x*y == y*x

p_asociativaProducto :: Nat -> Nat -> Nat -> Property
p_asociativaProducto x y z = True ==> (x*y)*z == x*(y*z)

p_neutroProducto :: Nat -> Property
p_neutroProducto x = True ==> x*uno == x


p_asociativaInduccion :: Nat -> Nat -> Nat -> Property
p_asociativaInduccion x y z = (x+y)+z == x+(y+z) ==> (Suc x + Suc y) + Suc z == Suc x +(Suc y + Suc z)

-- 36
data Vector = V Double Double Double 

instance Show Vector where
        show (V x y z) = concat (zipWith (++) vs ["i","j","k"])
            where 
                vs =show x : map conSigno [y,z]
                conSigno x = (if x>=0 then " + " else " - ") ++ show (abs x)

v1,v2 ::Vector
v1 = V 1 (-3) 2
v2 = V (-2) 5 9

instance Eq Vector where 
    (V ux uy uz) == (V vx vy vz) = ux == vx && uy == vy && uz == vz

zipWithVector :: (Double -> Double -> Double) -> Vector -> Vector -> Vector
zipWithVector f (V ux uy uz) (V vx vy vz) = V (f ux vx) (f uy vy) (f uz vz)

instance Num Vector where 
    (+) v1 v2 = zipWithVector (+) v1 v2
    (-) v1 v2 = zipWithVector (-) v1 v2
    (*) (V ux uy uz) (V vx vy vz) = (zipWithVector (*) (V uy uz ux) (V vz vx vy)) - (zipWithVector (*) (V uz ux uy) (V vy vz vx))
    abs v1 = error "sin sentido"
    signum = error "sin sentido"
    fromInteger x = V (fromInteger x) (fromInteger x) (fromInteger x)

instance Arbitrary Vector where
    arbitrary = do
        x <- arbitrary
        y <- arbitrary
        z <- arbitrary
        return (V x y z)


-- Las pruebas me aburren llevo demasiadas seguidas TODO

