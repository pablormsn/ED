package dataStructure.list;

public class ListException extends RuntimeException{
    public ListException(){super();}
    public ListException(String s){super(s);}
}
