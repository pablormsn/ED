package dataStructure.list;

import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.StringJoiner;

public class LinkedList<T> implements List<T> {

    private class Node<T> {
        public T value;
        public Node<T> next;

        public Node(T value,Node<T> next){
            this.value=value;
            this.next=next;
        }

        @Override
        public String toString() {
            return value.toString();
        }
    }

    private Node<T> first;
    private Node<T> last;
    private int size;

    public LinkedList(){
        first=null;
        last=null;
        size=0;
    }

    @Override
    public boolean isEmpty() {
        return size==0;
    }

    @Override
    public int size() {
        return size;
    }

    @Override
    public T get(int i) {
        return search(i).value;
    }

    @Override
    public void set(int i, T elem) {
        search(i).value=elem;
    }

    @Override
    public void prepend(T elem) {
        Node<T> temp =new Node<>(elem,first);
        first=temp;
        if (last==null) last=temp;
        size++;
    }

    @Override
    public void append(T elem) {
        Node<T> temp =new Node<>(elem,null);
        if (last==null) {
            first=temp;
        } else {
            last.next = temp;
        }
        last=temp;
        size++;
    }

    @Override
    public void insert(int i, T elem) {
        if (i==0 || size==0){
            prepend(elem);
        } else if (i==size) {
            append(elem);
        } else {
            Node<T> valorInsertar = new Node<>(elem,null);
            Node<T> anterior = search(i-1);
            valorInsertar.next=anterior.next;
            anterior.next=valorInsertar;
            size++;
        }
    }

    @Override
    public void delete(int i) {
        if (i!=0){
            Node<T> anterior = search(i-1);
            anterior.next=anterior.next.next;
        } else {
            first=first.next;
        }
        size--;
        if (size==0) {
            last=null;
            first=null;
        }
    }
    private Node<T> search(int pos){
        if (pos>=size || pos<0) throw new ListException("Bad index. List size "+size);
        if (pos==size-1) return last;
        Node<T> temp = first;
        int i=0;
        while (i<pos){
            temp=temp.next;
            i++;
        }
        return temp;
    }

    @Override
    public String toString() {
        StringJoiner temp = new StringJoiner(",","[","]");
        Node<T> nextNode = first;
        for (int i = 0; i<size;i++){
            temp.add(nextNode.toString());
            nextNode=nextNode.next;
        }
        return temp.toString();
    }
    private class LinkedListIterator implements Iterator<T>{
        Node<T> node;
        public LinkedListIterator(){
            node=first;
        }

        @Override
        public boolean hasNext() {
            return node.next!=null;
        }

        @Override
        public T next() {
            if (node==null) throw new NoSuchElementException();
            T elem =node.value;
            node=node.next;
            return elem;
        }
    }
    public Iterator<T> iterator(){
        return new LinkedListIterator();
    }
}
