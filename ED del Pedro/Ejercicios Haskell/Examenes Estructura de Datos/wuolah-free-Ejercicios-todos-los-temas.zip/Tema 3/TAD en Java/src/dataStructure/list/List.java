package dataStructure.list;

import java.util.Iterator;

public interface List<T> extends Iterable<T>{
    /**
     * returns if the list is empty
     * @return if the list is empty
     */
    boolean isEmpty();

    /**
     * number of elements contained
     * @return list size
     */
    int size();

    /**
     * returns value stored at the index
     * @param i
     * @return value stored
     */
    T get(int i);

    /**
     * sets the element at i to another value
     * @param i
     * @param elem
     */
    void set(int i, T elem);

    /**
     * adds the element at the start of the list
     * @param elem
     */
    void prepend(T elem);

    /**
     * adds the element at the end of the list
     * @param elem
     */
    void append(T elem);

    /**
     * insert element at index i
     * @param i
     * @param elem
     */
    void insert(int i, T elem);

    /**
     * Deletes element at index i
     * @param i
     */
    void delete(int i);
}
