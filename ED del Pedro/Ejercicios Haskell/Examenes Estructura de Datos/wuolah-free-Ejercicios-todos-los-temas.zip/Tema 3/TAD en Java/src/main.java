import dataStructure.list.LinkedList;
import dataStructure.list.List;

public class main {
    public static void main(String[] args) {
        List<Integer> lista = new LinkedList<>();
        lista.append(9);
        System.out.println(1 +lista.toString());

        lista.prepend(1);
        System.out.println(2 +lista.toString());

        lista.prepend(2);
        System.out.println(3 + lista.toString());

        lista.append(3);
        System.out.println(4 + lista.toString());

        lista.insert(1,5);
        System.out.println(5 + lista.toString());

        lista.delete(0);
        System.out.println(6 + lista.toString());

        lista.set(2,10);
        System.out.println(7 + lista.toString());
        while (!lista.isEmpty()){
            lista.delete(0);
        }
        System.out.println(lista);
        lista.append(3);
        lista.append(4);
        lista.append(5);
        lista.insert(0,1);
        lista.insert(4,100);
        System.out.println(lista);
    }
}
