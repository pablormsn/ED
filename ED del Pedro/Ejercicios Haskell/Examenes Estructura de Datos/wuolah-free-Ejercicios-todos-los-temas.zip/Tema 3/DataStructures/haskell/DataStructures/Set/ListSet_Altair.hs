module LinearSet(
    isEmpty,
    insert,
    delete,
    isElem,
    empty
) where

data Set a = St [a] deriving Show

isEmpty :: Set a -> Bool
isEmpty (St []) =True
isEmpty (St _) =False

insert :: Eq a => a -> Set a -> Set a
insert e s@(St xs)
    | elem e xs = s
    |otherwise = St (e:xs)

delete :: Eq a => a -> Set a -> Set a
delete e (St xs) = St (filter ((==) e) xs )

isElem :: Eq a => a ->  Set a -> Bool
isElem e (St xs) = elem e xs


empty :: Set a
empty = St []
