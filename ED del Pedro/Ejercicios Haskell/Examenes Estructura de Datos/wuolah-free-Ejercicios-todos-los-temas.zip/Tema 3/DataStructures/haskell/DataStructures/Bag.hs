module Bag(
    empty,
    isEmpty,
    insert,
    occurrences,
    delete
)where

import Test.QuickCheck


data Bag a = Empty | Node a Int (Bag a) deriving Show

empty :: Bag a
empty = Empty

isEmpty :: Bag a -> Bool
isEmpty Empty = True
isEmpty _     = False

insert :: (Ord a) =>a-> Bag a -> Bag a
insert x Empty = Node x 1 Empty
insert x all@(Node e n b)
    | x == e = Node e (n+1) b
    | x <  e = Node x 1 all
    | x >  e = Node e n (insert x b)

occurrences :: (Ord a) => a -> Bag a -> Int 
occurrences _ Empty = 0
occurrences x (Node e n b)
    | x == e = n
    | x <  e = 0
    | x >  e = occurrences x b

delete :: (Ord a) => a -> Bag a -> Bag a
delete x Empty = Empty
delete x all@(Node e n b)
    | x == e = b
    | x <  e = all
    | x >  e = Node e n (delete x b)


instance (Ord a, Arbitrary a) => Arbitrary (Bag a) where 
    arbitrary = do
        xs <- listOf arbitrary
        return (foldr insert empty xs)