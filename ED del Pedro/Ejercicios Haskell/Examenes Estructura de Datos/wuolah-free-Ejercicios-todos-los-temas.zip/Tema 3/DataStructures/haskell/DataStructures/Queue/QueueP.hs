module QueueP(
    isEmpty,
    enqueue,
    dequeue,
    first,
    empty
)where

data QueueP a = Empty | Node a (QueueP a) deriving (Show)

isEmpty :: QueueP a -> Bool
isEmpty Empty = True
isEmpty (Node _ _) = False

enqueue :: (Ord a) => a -> QueueP a -> QueueP a 
enqueue x Empty = Node x Empty
enqueue x all@(Node e q) 
    | x <e = Node x all 
    | otherwise = Node e (enqueue x q)

dequeue :: QueueP a -> QueueP a
dequeue Empty = error "No quedan elementos"
dequeue (Node _ q) = q

first :: QueueP a -> a
first Empty = error "No quedan elementos"
first (Node x _) = x

empty :: QueueP a
empty = Empty
