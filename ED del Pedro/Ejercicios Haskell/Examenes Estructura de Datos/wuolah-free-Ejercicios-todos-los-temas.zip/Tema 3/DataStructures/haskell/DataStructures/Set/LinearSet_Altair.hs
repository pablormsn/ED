module LinearSet(
    isEmpty,
    insert,
    delete,
    isElem,
    empty
) where

data Set a = Empty | Node a (Set a) deriving Show

isEmpty :: Set a -> Bool
isEmpty Empty =True
isEmpty _ = False

insert :: Eq a => a -> Set a -> Set a
insert x Empty = Node x Empty
insert x all@(Node e s)
    | x == e = all
    | otherwise = Node e (insert x s)

delete :: Eq a => a -> Set a -> Set a
delete x Empty = Empty
delete x (Node e s) 
    | e == x = s
    | otherwise = Node e (delete x s)

isElem :: Eq a => a ->  Set a -> Bool
isElem x Empty = False
isElem x (Node e s) 
    | x == e = True
    | otherwise = isElem x s

empty :: Set a
empty = Empty