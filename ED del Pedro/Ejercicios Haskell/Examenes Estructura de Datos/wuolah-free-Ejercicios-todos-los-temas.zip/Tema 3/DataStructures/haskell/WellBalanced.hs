-------------------------------------------------------------------------------
-- Estructuras de Datos. 2o Curso. ETSI Informática. UMA --
-- (completa y sustituye los siguientes datos)
-- Titulación: Grado en Ingeniería del Software .

-- Fecha de entrega: DIA | MES | AÑO --
-- Relación de Ejercicios 3. Ejercicios resueltos: ..........
-- ------------------------------------------------------------------------------- 
module WellBalanced where

import Test.QuickCheck
import DataStructures.Stack.LinearStack 
wellBalanced :: String -> Bool 
wellBalanced xs = wellBalanced' xs empty

wellBalanced' :: String -> Stack Char -> Bool 
wellBalanced' [] s = isEmpty s
wellBalanced' (x:xs) s
    | x=='(' || x=='{' || x=='[' = wellBalanced' xs (push x s)
    | x==')' = '(' == top s && wellBalanced' xs (pop s)
    | x==']' = '['== top s && wellBalanced' xs (pop s)
    | x=='}' = '{'== top s && wellBalanced' xs (pop s)
    | otherwise = wellBalanced' xs s

