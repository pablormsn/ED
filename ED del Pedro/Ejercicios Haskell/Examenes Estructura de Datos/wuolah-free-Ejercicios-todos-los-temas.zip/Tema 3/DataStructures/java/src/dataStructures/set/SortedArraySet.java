package dataStructures.set;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Iterator;
import java.util.StringJoiner;

public class SortedArraySet <T extends Comparable<? super T>> implements Set<T> {

    private int size;
    private T [] array;

    public SortedArraySet(){
        array=(T[]) new Comparable[10];
        size=0;
    }

    private int searchEqOrBigger(T search){
        int i=0;
        while (i<size && search.compareTo((T) array[i])>0){
            i++;
        }
        return i;
    }

    @Override
    public boolean isEmpty() {
        return size==0;
    }

    @Override
    public int size() {
        return size;
    }

    @Override
    public void insert(T x) {
        checkAndExpand();
        int index = searchEqOrBigger(x);
        if (size==index) {
            array[index] = x;
            size++;
        } else {
            if (!array[index].equals(x)) {
                T insertar = x;
                T temp;
                while (index <= size) {
                    temp = array[index];
                    array[index] = insertar;
                    insertar = temp;
                    index++;
                }
                size++;
            }
        }
    }

    private void checkAndExpand() {
        if (size+1==array.length) array = Arrays.copyOf(array,array.length*2);
    }

    @Override
    public boolean isElem(T x) {
        return size!=0 && array[searchEqOrBigger(x)].equals(x);
    }

    @Override
    public void delete(T x) {
        int index = searchEqOrBigger(x);
        if (array [index] !=null && array[index].equals(x)){
            T insertar = array[index];
            while (index+1 < size) {
                array[index] = insertar;
                index++;
                insertar = array[index+1];

            }
            size--;
        }
    }

    @Override
    public Iterator<T> iterator() {
        return new SortedArraySetIterator();
    }
    private class SortedArraySetIterator implements Iterator<T>{
        private int index;
        public SortedArraySetIterator() {
            index=0;
        }
        @Override
        public boolean hasNext() {
            return index<size;
        }

        @Override
        public T next() {
            return array[index++];
        }
    }

    @Override
    public String toString() {
        StringJoiner stringJoiner = new StringJoiner(", ","[","]");
        for (int i = 0 ; i< size;i++){
            stringJoiner.add(((T) array[i]).toString());
        }
        return stringJoiner.toString();
    }
}
