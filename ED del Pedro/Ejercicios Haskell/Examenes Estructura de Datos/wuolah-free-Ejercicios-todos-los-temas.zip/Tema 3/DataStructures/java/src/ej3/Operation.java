package ej3;

public abstract class Operation extends Item{
    @Override
    public boolean isOperation() {
        return true;
    }
}
