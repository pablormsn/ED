package ej3;

import dataStructures.stack.*;

public class PostFix {
    public static int postFix(Item [] a){
        return postFix(a,0,new ArrayStack<Item>());
    }

    public static int postFix (Item [] a , int pointer , Stack<Item> stack){
        if (pointer==a.length) {
            return stack.top().getValue();
        }else {
            Item item = a[pointer];
            if (item.isData()) {
                stack.push(item);
            } else {
                int v2 = stack.top().getValue();
                stack.pop();

                int v1 = stack.top().getValue();
                stack.pop();

                Item resOp = new Data(item.evaluate(v1 ,v2));
                stack.push(resOp);
            }
            return postFix(a, pointer + 1, stack);
        }
    }

    public static void main(String[] args) {
        System.out.println(postFix(new Item [] {
                new Data(5),
                new Data(6),
                new Data(2),
                new Dif(),
                new Data(3),
                new Mul(),
                new Add() }));
    }
}
