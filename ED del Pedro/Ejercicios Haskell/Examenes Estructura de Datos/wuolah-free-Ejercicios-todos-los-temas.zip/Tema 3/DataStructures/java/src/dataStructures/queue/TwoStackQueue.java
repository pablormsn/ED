package dataStructures.queue;

import dataStructures.stack.ArrayStack;
import dataStructures.stack.Stack;

public class TwoStackQueue<T> implements Queue<T>{
    Stack<T> out; //De donde sacamos
    Stack<T> in; //De donde metemos
    int size;

    public TwoStackQueue(){
        out = new ArrayStack<>();
        in = new ArrayStack<>();
        size=0;
    }
    @Override
    public boolean isEmpty() {
        return size==0;
    }

    @Override
    public void enqueue(T x) {
        in.push(x);
        size++;
    }

    @Override
    public T first() {
        if (size==0) throw new EmptyQueueException();
        if (out.isEmpty()) reArrangeStacks();
        return out.top();
    }

    private void reArrangeStacks() {
        while (!in.isEmpty()){
            out.push(in.top());
            in.pop();
        }
    }

    @Override
    public void dequeue() {
        out.pop();
        size--;
    }
}
