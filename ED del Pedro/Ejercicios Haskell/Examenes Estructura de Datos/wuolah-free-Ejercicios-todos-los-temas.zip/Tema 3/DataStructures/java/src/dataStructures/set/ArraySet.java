package dataStructures.set;

import java.util.Arrays;
import java.util.Iterator;

public class ArraySet<T> implements Set<T> {
    private T [] array;
    private int size;

    public ArraySet(){
        this(10);
    }
    private int search (T elem) {
        int pos =-1;
        for (int i=0 ; i<size && pos==-1;i++){
            if (array[i] == elem) pos =i;
        }
        return pos;
    }
    @SuppressWarnings("unchecked")
    public ArraySet(int tam){
        array= (T []) new Object [tam];
        size=0;
    }
    @Override
    public boolean isEmpty() {
        return size==0;
    }

    @Override
    public int size() {
        return size;
    }

    @Override
    public void insert(T x) {
        if (!isElem(x)){
            checkSize();
            array[size++] = x;
        }
    }
    private void checkSize(){
        if (size+1==array.length){
            array=Arrays.copyOf(array,array.length*2);
        }
    }

    @Override
    public boolean isElem(T x) {
        return search(x)!=-1;
    }

    @Override
    public void delete(T x) {
        int pos = search(x);
        if (pos!=-1){
            array[pos] = array[--size];
        }
    }

    @Override
    public Iterator<T> iterator() {
        return new ArraySetIterator<>();
    }
    private class ArraySetIterator<T> implements Iterator<T> {
        private int p;
        public ArraySetIterator(){
            p =0;
        }
        @Override
        public boolean hasNext() {
            return p <size;
        }

        @Override
        public T next() {
            return (T) array[p++];
        }
    }
}
