import dataStructures.set.Set;
import dataStructures.set.SortedArraySet;
import java.util.ArrayList;

public class main {
    public static void main(String[] args) {
        Set<Integer> set = new SortedArraySet<>();
        System.out.println(set);
        set.insert(1);
        set.insert(3);
        set.insert(4);
        set.insert(2);
        set.insert(3);
        System.out.println(set);

        set.delete(5);
        set.delete(1);
        set.delete(2);
        set.delete(3);
        set.delete(4);
        set.delete(1);
        System.out.println(set);

        System.out.println(set.isElem(1));
        set.insert(1);
        System.out.println(set.isElem(2));
    }
}
