package ej3;

public class Data extends Item {
    private int value;
    public Data(int i){
        value=i;
    }

    @Override
    public boolean isData() {
        return true;
    }

    @Override
    public int getValue() {
        return value;
    }
}
