package ej3;

public class Add extends Operation{
    @Override
    public int evaluate(int a1, int a2) {
        return a1 +a2;
    }
}
