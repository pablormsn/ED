import dataStructures.stack.*;

public class WellBalanced {
    private final static String OPEN_PARENTHESES ="{[(";
    private final static String CLOSED_PARENTHESES = "}])";

    public static void main(String[] args) {
        System.out.println(wellBalanced("ff(h([sds)sds]ss)hags", new ArrayStack<Character>()));
    }
    public static boolean wellBalanced(String exp, Stack<Character> stack) {
        boolean sol=true;
        for (int i = 0; i<exp.length() && sol;i++){
            char c = exp.charAt(i);
            if (isOpenParentheses(c)){
                stack.push(c);
            }else if (isClosedParentheses(c)){
                sol=match(stack.top(),c);
                stack.pop();
            }
        }
        return sol && stack.isEmpty();
    }
    public static boolean isOpenParentheses(char c) {
        return OPEN_PARENTHESES.contains(Character.toString(c));
    }
    public static boolean isClosedParentheses(char c) {
        return CLOSED_PARENTHESES.contains(Character.toString(c));
    }
    public static boolean match(char x, char y) {
        return OPEN_PARENTHESES.indexOf(Character.toString(x)) ==
                CLOSED_PARENTHESES.indexOf(Character.toString(y));
    }
}
