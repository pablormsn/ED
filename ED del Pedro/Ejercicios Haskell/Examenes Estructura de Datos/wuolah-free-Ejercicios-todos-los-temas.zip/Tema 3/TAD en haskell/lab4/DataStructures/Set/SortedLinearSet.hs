-------------------------------------------------------------------------------
-- Linear implementation of Sets with nodes sorted according to values
-- and non-repeated elements
--
-- Data Structures. Grado en Informática. UMA.
--

-------------------------------------------------------------------------------

module DataStructures.Set.SortedLinearSet 
  ( Set
  , empty
  , isEmpty
  , size
  , insert
  , isElem
  , delete

  , fold

  , union
  , intersection
  , difference  
  ) where

import Data.List(intercalate)
import Test.QuickCheck

-- Invariants for this data structure:
--  * (INV1) All Nodes store different elements (no repetitions)
--  * (INV2) Nodes are sorted in ascending order with 
--           respect to values of their elements
--
-- An example of a well constructed set:
--   Node 2 (Node 5 (Node 8 Empty))
--
-- Examples of wrong sets:
--   Node 2 (Node 5 (Node 5 (Node 8 Empty))) -- REPETITION OF ELEMENT 5!
--   Node 7 (Node 1 (Node 8 Empty)) -- ELEMENTS NOT IN ASCENDING ORDER!

data Set a  = Empty | Node a (Set a)

empty :: Set a
empty = Empty

isEmpty :: Set a -> Bool
isEmpty Empty = True
isEmpty _     = False

isElem :: (Ord a) => a -> Set a -> Bool
isElem _ Empty = False 
isElem x (Node n s)
  | x == n = True
  | x>n = isElem x s
  | otherwise = False

insert :: (Ord a) => a -> Set a -> Set a
insert x Empty = Node x Empty
insert x (Node n s)
  | x > n = (Node n (insert x s))
  | x < n = (Node x (Node n s))
  | otherwise = (Node n s)


delete :: (Ord a) => a -> Set a -> Set a
delete _ Empty = Empty
delete x all@(Node n s)
  | x == n = s
  | x < n  = all
  | otherwise = Node n (delete x s)

size :: Set a -> Int
size Empty = 0
size (Node n s)= 1 + size s

fold :: (a -> b -> b) -> b -> Set a -> b
fold f z = fun
 where
  fun Empty       = z
  fun (Node x s)  = f x (fun s)

union :: (Ord a) => Set a -> Set a -> Set a
union a Empty = a
union Empty a = a
union xx@(Node x xs) yy@(Node y ys)
  | x==y = (Node x (union xs ys))
  | x<y  = (Node x (union xs yy))
  | x>y  = (Node y (union xx ys))

difference :: (Ord a) => Set a -> Set a -> Set a
difference x Empty = x
difference Empty _ = Empty
difference xx@(Node x xs) yy@(Node y ys)
  | x == y = difference xs ys
  | x <  y = Node x (difference xs yy)
  | x >  y = difference xx ys

intersection :: (Ord a) => Set a -> Set a -> Set a
intersection _ Empty = Empty
intersection Empty _ = Empty
intersection xx@(Node x xs) yy@(Node y ys)
  | x == y = Node x (intersection xs ys)
  | x <  y = intersection xs yy
  | x >  y = intersection xx ys





-- Showing a set
instance (Show a) => Show (Set a) where
  show s  = "SortedLinearSet(" ++ intercalate "," (strings s) ++ ")"
    where
      strings Empty       = []
      strings (Node x s)  = show x : strings s

-- Set equality
instance (Eq a) => Eq (Set a) where
  Empty      == Empty         = True
  (Node x s) == (Node x' s')  = x==x' && s==s'
  _          == _             = False

-- This instance is used by QuickCheck to generate random sets
instance (Ord a, Arbitrary a) => Arbitrary (Set a) where
    arbitrary  = do
      xs <- listOf arbitrary
      return (foldr insert empty xs)

