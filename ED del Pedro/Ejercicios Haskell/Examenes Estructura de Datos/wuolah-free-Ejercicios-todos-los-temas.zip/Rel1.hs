
-------------------------------------------------------------------------------
-- Estructuras de Datos. 2o Curso. ETSI Informática. UMA --
-- (completa y sustituye los siguientes datos)
-- Titulación: Grado en Ingeniería .......................................... del Software

-- Fecha de entrega: 19 | 10 | 2020 --
-- Relación de Ejercicios 1. Ejercicios resueltos: Todos
-- ------------------------------------------------------------------------------- 

import Test.QuickCheck



--1)
esTerna :: Integer -> Integer -> Integer ->Bool
esTerna x y z = x^2 +y^2 ==z^2

terna :: Integer -> Integer ->(Integer,Integer,Integer)
terna x y = (x^2-y^2,2*x*y,x^2+y^2)

p_ternas x y = x>0 && y>0 && x>y ==> esTerna l1 l2 h 
    where (l1 , l2 , h) = terna x y


--2)
intercambia :: (a,b) ->(b,a)
intercambia (x,y) = (y,x)


--3)
ordena2 :: Ord a => (a,a) ->(a,a)
ordena2 (x, y) = if x<y then (x,y) else (y,x)

p1_ordena2 :: Ord a => a -> a -> Property
p1_ordena2 x y = True ==> enOrden (ordena2 (x,y))
    where enOrden (x,y) = x<=y

p2_ordena2 :: Ord a => a -> a -> Bool
p2_ordena2 x y = mismosElementos (x,y) (ordena2 (x,y))
    where mismosElementos (x,y) (z,v) = (x==z && y==v) || (x==v && y==z)

ordena3 :: Ord a => (a,a,a) -> (a,a,a)
ordena3 (x,y,z)
    | x>z = ordena3 (z,y,x)
    | x>y = ordena3 (y,x,z)
    | y>z = ordena3(x,z,y)
    |otherwise = (x,y,z) 

p1_ordena3 :: Ord a => a -> a ->a -> Property
p1_ordena3 x y z = True ==> enOrden (ordena3 (x,y,z))
    where enOrden (x,y,z) = x<=y && y<=z

p2_ordena3 :: Ord a => a -> a -> a -> Property
p2_ordena3 x y z = True ==> mismosElementos (x,y,z) (ordena3 (x,y,z))
    where mismosElementos (x,y,z) (o,p,q) = (x==o && y==p) || (x==o && y==q)


-- 4)
max2 :: Ord a => a -> a -> a
max2 x y = if x>y then x else y

p1_max2 x y = True ==> maximo == x || maximo ==y
    where maximo = max2 x y

p2_max2 x y = True ==> maximo >=x && maximo >=y
    where maximo = max2 x y

p3_max2 x y = True ==> if x>=y then maximo ==x else maximo ==y
    where maximo = max2 x y

p4_max2 x y = True ==> if y>=x then maximo == y else maximo ==x
    where maximo = max2 x y


-- 5)
entre :: Ord a => a -> (a,a) -> Bool
entre x (y,z) = x>=y && x<=z


-- 6)
iguales3 :: Eq a => (a,a,a) -> Bool
iguales3 (x,y,z) = x==y && y==z


-- 7)
type TotalSegundos = Integer
type Horas =Integer
type Minutos = Integer
type Segundos = Integer

descomponer :: TotalSegundos -> (Horas,Minutos,Segundos) 
descomponer x = (horas, minutos, segundos)
    where horas = x `div`3600
          minutos = x `div`60 - horas*60
          segundos = x - (minutos*60) -(horas*3600)

p_descomponer x = x>=0 ==> h*3600 + m*60 + s == x && entre m (0,59)&& entre s (0,59) 
    where (h,m,s) = descomponer x


-- 8)
unEuro :: Double
unEuro = 166.386

pesetasAEuros :: Double -> Double
pesetasAEuros x = x / unEuro

eurosAPesetas :: Double -> Double
eurosAPesetas x = x * unEuro

p_inversas x = True ==> eurosAPesetas (pesetasAEuros x) ~= x 


-- 9)
infix 4 ~=
(~=) :: Double -> Double -> Bool 
x ~= y = abs (x-y) < epsilon
    where epsilon = 1/1000


-- 10)
raíces a b c 
    |delta <0 = error "Raíces no reales"
    |otherwise = ((-b +sqrt delta)/(2*a) ,(-b-sqrt delta)/(2*a))
        where delta = b^2 - 4*a*c ::Double

p1_raíces a b c = a/=0 && delta >=0 ==> esRaíz r1 && esRaíz r2 
    where (r1,r2) = raíces a b c
          esRaíz r = a*r^2 + b*r + c ~= 0
          delta = b^2 - 4*a*c ::Double


-- 11)
esMúltiplo ::(Integral a) => a-> a-> Bool
esMúltiplo x y = x `mod` y ==0


-- 12)
(==>>) :: Bool -> Bool -> Bool
False ==>> y     = True
True  ==>> True  = True
True  ==>> False = False


-- 13)
esBisiesto :: (Integral a) => a->Bool
esBisiesto x
    |x `esMúltiplo` 100 = x `esMúltiplo` 400 
    |x `esMúltiplo` 4 =True
    |otherwise =False


-- 14)
potencia :: (Integral a) => a->a->a
potencia _ 0 = 1
potencia 0 _ =0
potencia x y = x * potencia x (y-1)


potencia':: Integer->Integer->Integer
potencia' x n  
    |(n==1) = x
    |even n = (potencia' x (div n 2))*(potencia' x (div n 2)) 
    |odd n  = x * (potencia' x (n-1))


p_pot b n = n>=0 ==> potencia b n == sol && potencia' b n == sol
    where sol = b^n

-- Apartado d: La mitad


-- 15)
factorial :: Integer ->Integer
factorial 0 = 1
factorial n = n * factorial (n - 1)


-- 16)
divideA x y = y `mod` x==0

p1_divideA x y = y/=0 && y `divideA` x ==> div x y * y == x

p2_divideA x y z = x/=0 && x `divideA`y && x `divideA`z ==> x `divideA`(y+z)


-- 17)
mediana :: Ord a => (a,a,a,a,a) -> a
mediana (x,y,z,u,v)
    |x > z = mediana (z,y,x,u,v) 
    |y > z = mediana (x,z,y,u,v)
    |x > y = mediana (y,x,z,u,v)
    |z > u = mediana (x,y,u,z,v)
    |z > v = mediana (x,y,v,u,z)
    |otherwise = z 